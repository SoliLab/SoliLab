# [MSSDK](https://github.com/jindaxiang/mssdk) 量化平台

## 开源平台

- [Backtrader](https://www.backtrader.com/)
- [VN.PY](https://www.vnpy.com/)
- [功夫量化](https://www.kungfu-trader.com/)

## 网页端

- [JoinQuant](https://www.joinquant.com/)
- [MyQuant](https://www.myquant.cn/)
- [BigQuant](https://bigquant.com/)
- [WindQuant](https://www.windquant.com/)
- [DigQuant](http://www.digquant.com.cn/)
