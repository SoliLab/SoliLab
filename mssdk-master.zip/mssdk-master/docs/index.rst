.. mssdk documentation master file, created by
   sphinx-quickstart on Wed Apr  1 16:46:12 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

欢迎来到成都麦思多维科技 Python SDK 文档
=================================================================================

.. toctree::
   :maxdepth: 2
   :glob:
   :caption: Table of contents:

   introduction
   installation
   answer
   tutorial
   data/index
   anaconda
   special
   strategy
   platform
   topic/index
   demo
   changelog
